import { StyleSheet, View, SafeAreaView, Image } from 'react-native'
import Loja from './components/Loja'
import Lanche from './components/Lanche'
export default function App() {
  const listaLanches = [
    {
      img: require('./assets/Imagens/lanche.jpeg'), 
      preco:'25,50',
    },
    {
      img: require('./assets/Imagens/lanche.jpeg'), 
      preco:'25,50',
    },
        {
      img: require('./assets/Imagens/lanche.jpeg'), 
      preco:'25,50',
    },
        {
      img: require('./assets/Imagens/lanche.jpeg'), 
      preco:'25,50',
    },
        {
      img: require('./assets/Imagens/lanche.jpeg'), 
      preco:'25,50',
    },
        {
      img: require('./assets/Imagens/lanche.jpeg'), 
      preco:'25,50',
    },
        {
      img: require('./assets/Imagens/lanche.jpeg'), 
      preco:'25,50',
    },
        {
      img: require('./assets/Imagens/lanche.jpeg'), 
      preco:'25,50',
    },
        {
      img: require('./assets/Imagens/lanche.jpeg'), 
      preco:'25,50',
    },
    {
      img: require('./assets/Imagens/lanche.jpeg'), 
      preco:'25,50',
    },
    {
      img: require('./assets/Imagens/lanche.jpeg'), 
      preco:'25,50',
    },
    {
      img: require('./assets/Imagens/lanche.jpeg'), 
      preco:'25,50',
    }
  ];
  return (
    <SafeAreaView style={css.container}>
    <View style={css.logo}>
     <Image style={css.imagem_logo} source={require('./assets/Imagens/ifood.png')} />
    </View>
    <View style={css.linha}>
      <Loja imagem={require('./assets/Imagens/confiança.png')}/>
      <Loja imagem={require('./assets/Imagens/tauste.png')}/>
      <Loja imagem={require('./assets/Imagens/kozan.jpg')}/>
      <Loja imagem={require('./assets/Imagens/mac.png')}/>
    </View>
    <View style={css.box}>
       <Lanche img={listaLanches[0].img} preco={listaLanches[0].preco}/>
       <Lanche img={listaLanches[1].img} preco={listaLanches[1].preco}/>
       <Lanche img={listaLanches[2].img} preco={listaLanches[2].preco}/>
       <Lanche img={listaLanches[3].img} preco={listaLanches[3].preco}/>
       <Lanche img={listaLanches[4].img} preco={listaLanches[4].preco}/>
       <Lanche img={listaLanches[5].img} preco={listaLanches[5].preco}/>
       <Lanche img={listaLanches[6].img} preco={listaLanches[6].preco}/>
       <Lanche img={listaLanches[7].img} preco={listaLanches[7].preco}/>
       <Lanche img={listaLanches[8].img} preco={listaLanches[8].preco}/>
       <Lanche img={listaLanches[9].img} preco={listaLanches[9].preco}/>
       <Lanche img={listaLanches[10].img} preco={listaLanches[10].preco}/>
       <Lanche img={listaLanches[11].img} preco={listaLanches[11].preco}/>
    </View>
    </SafeAreaView>
  );
}

const css = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'start',
    backgroundColor: '#ff001b',
    alignItems:'center',
  },
  logo: {
    borderRadius:10,
    width:'90%',
    height:120,
    alignItems:'center',
    justifyContent:'center',
  },
  imagem_logo:{
    width:150,
    height:100,
  },
  linha:{
    width:'100%',
    flexDirection:'row',
    justifyContent:'space-around',
    alignItems:'center',
    marginVertical: 10,
  },
  box: {
    height: '70%',
    width:'95%',
    flexWrap: 'wrap',
    flexDirection:'row',
    justifyContent:'space-around',
    alignContent:'flex-start'
  }
});
