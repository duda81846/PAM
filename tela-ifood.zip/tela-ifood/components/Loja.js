import {View, StyleSheet, Text, Image } from 'react-native'

export default function Loja({imagem}){
  return(
    <View style={css.bolinha}>
      <Image style={css.logo_bolinha} source={imagem} />
    </View>
  )
}

const css = StyleSheet.create({
  logo_bolinha:{
    height:60,
    width:60
  },
  bolinha:{
    backgroundColor:'#fff',
    width:75,
    height:75,
    borderRadius:75,
    justifyContent:'center',
    alignItems:'center'
  }
})