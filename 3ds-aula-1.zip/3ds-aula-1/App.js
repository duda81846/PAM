import { StyleSheet, Text, View } from 'react-native';
import Texto from './Texto'
import CEP from './Cep'

export default CEP 

function App() {
  return (
    <View style={styles.alinhamento}>
      <Text style={styles.paragraph}>
        Hello World
      </Text>
      <Text style={styles.paragraph2}>
        Parte 2
      </Text>
      <Text style={styles.paragraph3}>
        Parte 3
      </Text>
      <Texto texto1="1" />
      <Texto texto1="1" />
      <Texto texto1="1" />
      <Texto texto1="1" />
      
    </View>
  );
  
}

const styles = StyleSheet.create({
  container:  {
  },
  paragraph: {
    fontSize: 55,
    fontWeight: 'bold',
    textAlign: 'center',
    
    borderWidth:10,
    backgroundColor:'red'
  },
    paragraph2: {
    fontSize: 100,
    textAlign: 'center',
    borderWidth:5,
    backgroundColor:'blue'
  },
    paragraph3: {
      backgroundColor:'pink'
  },
  alinhamento:{
    alignItems:'center'
  }
});
//body=view
//n pode duas views
//clas="" é style={styles.nomedostyle}