import {View, Text, StyleSheet, TextInput, Button} from 'react-native'
import {useState} from 'react'
export default function CEP(){
  const [cep, setCep] = useState("")

  const buscarCEP = () => {
    var url = "https://viacep.com.br/ws/"+cep+"/json/"
    fetch(url)
    .then( (resposta) => resposta.json() )
    .then( (dados) => {
      alert(dados.logradouro+"  cidade: " +dados.localidade)
    })
  }
  return(
    <View style={css.container}>
    <Text>CEP</Text>
    <TextInput style={css.input} value={cep} onChangeText={(text)=> setCep(text)}/>
    <Button onPress={() => buscarCEP()} title={"Buscar CEP"}/>
    </View>
  );
}
const css = StyleSheet.create({
  container:{
    alignItems:'center',
    padding:20
  },
  input:{
    borderWidth:1,
    height:20,
    width:150
  }
})