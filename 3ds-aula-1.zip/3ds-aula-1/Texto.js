import { StyleSheet, Text, View } from 'react-native';

export default function Texto({texto1, texto2, texto3}) {
  return (
    <View style={css.container}>
    <View style={css.esquerda}>
    <Text>{texto1}</Text>
    </View>
    <View style={css.centro}>
    <Text>{texto2}</Text>
    </View>
    <View style={css.direita}>
    <Text>{texto3}</Text>
    </View>
    </View>
  )
}

const css = StyleSheet.create({
  container:{
    backgroundColor:'#B069DB',
    width:150,
    height:150,
    borderRadius:50,
    justifyContent:"center"
  },
  esquerda:{
    borderWidth:1,
    alignItems:'start',
    marginVertical:5
  },
  centro:{
    borderWidth:1,
    alignItems:'center',
    marginVertical:5
  },
  direita:{
    borderWidth:1,
    alignItems:'end',
    marginVertical:5
  }

})